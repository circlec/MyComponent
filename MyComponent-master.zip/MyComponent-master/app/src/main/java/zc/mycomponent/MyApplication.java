package zc.mycomponent;

import zc.commonlib.BaseApplication;

public class MyApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
