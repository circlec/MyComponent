package zc.account;

import zc.commonlib.BaseApplication;

/**
 * @作者 zhouchao
 * @日期 2019/11/7
 * @描述
 */
public class LoginApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
