package zc.commonlib.router;

/**
 * @作者 zhouchao
 * @日期 2019/11/8
 * @描述
 */
public class ARouterPath {

    public static final String APP_HOME = "/app/home";

    public static final String ACCOUNT_LOGIN = "/account/login";

    public static final String SETTING_SETTING = "/setting/setting";

    public static final String SETTING_TEST_MYTEST= "/setting/test/mytest";


}
